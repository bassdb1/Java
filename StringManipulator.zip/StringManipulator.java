public class StringManipulator {
 

    public Integer getIndexOrNull(String str, char c) {
        int b = str.indexOf(c);      

       return b;
    

     }

   

    public String concatSubstring(String a, String b) {
        String c = a.concat(b);
    
        return c;
    
     } 
}