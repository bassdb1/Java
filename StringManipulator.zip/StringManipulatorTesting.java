//import jdk.tools.jlink.internal.SymLinkResourcePoolEntry;

public class StringManipulatorTesting {
    public static void main(String[] args) {
        // ** In Order to use 'StringManipulator' 'Method' from the 'StringManipulator class', I have to make an 'instance, or copy' of it.  I do this below

        // Variable Type - Variable Name = new instance of object name = 'sm'.  I do this so I can use the 'StringManipulator "class methods, like, 'trimAndConcat'
         StringManipulator sm = new StringManipulator();
       
        // System.out.println(sm.trimAndConcat("       Apple", "      Orange"));

        // ** If I did not want to make an 'instance' of 'StringManipulator **' 
        // If I made the function static, I could use with the class name, instead of an object
    
        //    sm.getIndexOrNull("potato", "o");{

          // System.out.println(sm.getIndexOrNull("potato", 'o'));

          System.out.println(sm.concatSubstring("John", "Tanner"));

       }

      
  
    }





