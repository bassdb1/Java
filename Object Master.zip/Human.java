public class Human {

    
    //attributes, variables
    int strength = 3;
    int stealth = 3;
    int intelligence = 3;
    int health = 100;


    // Constructor
    // public Human(){

    // }


    // Attack Method

    public void attack(Human victim){
        System.out.println("attacking");
        victim.health-= this.strength;  // this.strength is being related to the one doing the call
    }

    public void displayInfo(){
        System.out.println("Human health is this: " + this.health);
    }

    
}
