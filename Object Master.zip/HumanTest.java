public class HumanTest {
    public static void main(String[]args){

        
        // creating a new Human Object 

        Human h1 = new Human();
        Human h2 = new Human();
        

        // Human objects using the Methods

        h2.displayInfo();  // This dispalys the Humans Health


        // The (h2) allows another human to attack another human

        
    // Attack Method
     
    // **** This method is from the Human Class ****

    //                    Human is what 'Data Type' 'Victim' is the one being attacked
    // public void attack(Human victim){
    //     System.out.println("attacking");
    //     victim.health-= this.strength;  // this.strength is being related to the one doing the call, 
    //       so below h1 is calling this method, this allows its strength to be deducted when being attacked        using the 'this' kwyword, representing 'this object'
    // }


        h1.attack(h2);
        
        // Displays health after attack
        h2.displayInfo();


       

        
    }
}
