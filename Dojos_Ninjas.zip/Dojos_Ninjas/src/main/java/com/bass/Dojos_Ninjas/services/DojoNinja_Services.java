package com.bass.Dojos_Ninjas.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.bass.Dojos_Ninjas.models.Dojo;
import com.bass.Dojos_Ninjas.models.Ninja;
import com.bass.Dojos_Ninjas.repositories.dojoRepository;
import com.bass.Dojos_Ninjas.repositories.ninjaRepository;

@Service
public class DojoNinja_Services {

	
	
	
	private dojoRepository dojoRepo;  
	private ninjaRepository ninjaRepo;
	
	// Constructor to allow everthing to come in
	
	// This gives us full access to both of our repositories
	
	public DojoNinja_Services(dojoRepository dojoRepo, ninjaRepository ninjaRepo) {
		super();
		this.dojoRepo = dojoRepo;
		this.ninjaRepo = ninjaRepo;
	}
	
	// What do we want our 'Services' to do?
	
	// Make a Dojo
	
	// This is like going to the MySQL and typing in a user manually, but we are having the 'interface' do this for us.  This will use the 'Dojo' Model - which allows you to 'Input the Name of the 'Dojo'
	// .. 'newDojo' is an instance of 'Dojo' and 'dojoRepo' is an instance of 'dojoRepository' which is using the 'CRUD' functionality, allowing us to 'Create' a Dojo.
	// ... '.save(newDojo) just simply saves the object.
	
	public Dojo create(Dojo newDojo) {
		return dojoRepo.save(newDojo);
	}
	
	// Make a Student
	
	public Ninja create(Ninja newNinja) {
		return ninjaRepo.save(newNinja);
	}
	
	// Display Dojos
	
	// This will list all of the Dojos
	public List<Dojo> getAllDojos() {
		return (List<Dojo>) dojoRepo.findAll();
	}
	
	
	// Displays Students
	
	// This will list all of the Ninjas
	
	public List<Ninja> getAllNinjas(){
		return (List<Ninja>) ninjaRepo.findAll();
	}
	
	// Display '1' Dojo
	
	public Dojo getDojo(Long id) {
		Optional<Dojo> optionalDojo = this.dojoRepo.findById(id);
		if(optionalDojo.isPresent()) {
			return optionalDojo.get();
		
		}else {
			return null;
		}
	}
	

}