package com.bass.Dojos_Ninjas.controllers;


import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.bass.Dojos_Ninjas.models.Dojo;
import com.bass.Dojos_Ninjas.models.Ninja;
import com.bass.Dojos_Ninjas.services.DojoNinja_Services;

// Add the 'Controller' Annotation

@Controller

public class HomeController {
	
	// Controller talks to 'Services' -'DojoNinja_Services' is my Service my name.  Have a variable referencing 'DojoNinja_Services' by dnServ
	
	private DojoNinja_Services dnServ;

	// Generate Constructor so it can add to the 'private class'
	
	public HomeController(DojoNinja_Services dnServ) {
		super();
		// 'this' references the current object.
		this.dnServ = dnServ;  // this is our service
	}
	
	// Render a view - a webpage
	// .. Gets a webpage
	
	//This is our Index and will show all of our Dojos
	@GetMapping("/")
	
	// Model holds the Model attributes.  We are referencing it with variable 'model'
	public String Index(Model model ) {
		model.addAttribute("allDojos", dnServ.getAllDojos());
		return "Index.jsp";
	}
	
	// We can Show 'One' Dojo and the Dojo's students
	// ... using @PathVariable to say we are bringing in a variable
	@GetMapping("/showDojo/{id}")
	public String showDojo (@PathVariable("id") Long id, Model model) {
		// Get Dojo
		Dojo myDojo =this.dnServ.getDojo(id);
		model.addAttribute("thisDojo", myDojo);   // myDojo is a reference to Dojo Model
		return "oneDojo.jsp";
	}

	
	
	// This is the JSP return for the form to create Dojo
	@GetMapping("/newDojo")
	public String dojo(@ModelAttribute("addDojo") Dojo dojo) {
		return "newDojo.jsp";
	}
		
	
	// Where we create our Dojo Action = /makeDojo
	
	// BindingResult using variable 'result' is for error collections
	
	// Making a 'Post Request' -- if no errors - it creates and adds to the Database
	
	// .. the "/makeaDojo" must match what is on our form in newDojo.jsp
	// .. also 'the @ModelAttribute addDojo - must be the same in newDojo.jsp
	@PostMapping("/makeaDojo")
	public String dojo(@ModelAttribute("addDojo") Dojo dojo, BindingResult result, Model model) {
		if (result.hasErrors()) {
			System.out.println(result.getAllErrors());
		} else
			dnServ.create(dojo);
		return "redirect:/";
	}
	
	
	// This is the JSP return for the form to create Ninjas - using 'New Ninja'
	
	// I will be using my 'Ninja Model'
		
	@GetMapping("/newNinja")
	public String ninja(@ModelAttribute("addNinja") Ninja ninja, Model model) {
		model.addAttribute("allDojos", dnServ.getAllDojos());
		return "newNinja.jsp";
		}
			
	
	// Where we create our Ninjas
	
	@PostMapping("/makeaNinja")
	public String ninja(@ModelAttribute("addNinja") Ninja ninja, BindingResult result, Model model) {
		if (result.hasErrors()) {
			System.out.println(result.getAllErrors());
		} else
			dnServ.create(ninja);
		return "redirect:/";
	}
	


	
	
	

	}
	

	


