package com.bass.Dojos_Ninjas.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


import com.bass.Dojos_Ninjas.models.Ninja;

@Repository
//we use extends 'Crud' so we can use its features
//<Dojo> is our Ninja Model, <Long> is the Data Type
public interface ninjaRepository extends CrudRepository<Ninja, Long> {

	// We want a 'List' of 'all' the Ninjas
		List<Ninja> findAll();
	}

