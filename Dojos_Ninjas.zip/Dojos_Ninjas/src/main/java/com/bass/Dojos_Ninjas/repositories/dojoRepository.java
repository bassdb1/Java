package com.bass.Dojos_Ninjas.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.bass.Dojos_Ninjas.models.Dojo;

@Repository

// we use extends 'Crud' so we can use its features
// <Dojo> is our Dojo Model, <Long> is the Data Type
public interface dojoRepository extends CrudRepository<Dojo, Long> {

	// We want a 'List' of 'all' the Dojos
	List<Dojo> findAll();
}
