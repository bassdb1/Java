package com.bass.Dojos_Ninjas.models;

import java.util.Date;
// This is used so we can use the 'List' feature
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;


@Entity
// Table name on our MySQL
@Table(name="dojos")

public class Dojo {

	
	
	@Id   // Used for Primary Key
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	//Validations
	
	@NotEmpty(message="You must put in a Dojo")
	private String name;
	
	// Creating our relationship from '1' Dojo to 'Many' Ninjas
	@OneToMany(mappedBy="dojo", fetch = FetchType.LAZY)
	// We want this to 'Fetch' the 'List' of Ninjas
	// .. we are fetching from the 'Ninja Table'
	// ... and store in the variable 'ninjas'
    private List<Ninja> ninjas;
	
	
	// Constructor
	
	public Dojo () {
	}


	public Dojo(@NotEmpty(message = "You must put in a Dojo") String name) {
		super();
		this.name = name;
	}

	// Generate 'Getters and Setters' why? Because we are using private
	
	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public List<Ninja> getNinjas() {
		return ninjas;
	}


	public void setNinjas(List<Ninja> ninjas) {
		this.ninjas = ninjas;
	}


	public Date getCreatedAt() {
		return createdAt;
	}


	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}


	public Date getUpdatedAt() {
		return updatedAt;
	}


	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}
	
	  private Date createdAt;
	  private Date updatedAt;
	
}
	
