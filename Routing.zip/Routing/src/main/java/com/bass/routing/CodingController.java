package com.bass.routing;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController

@RequestMapping("/coding")   // this will work as long as its not in the method

// Using 'RequestMapping annotation

public class CodingController {
	
	 @RequestMapping("")
		public String coding() {
			return "Hello Coding Dojo";
		}
		
		// Python Route
		@RequestMapping("/python")
		
			public String python(){
				return "Python/Django was awesome!";
			}
			
			
		//Python Route
		@RequestMapping("/java")
		
			public String java(){
				return "Java/Spring is better!";
			}
			

	

}
