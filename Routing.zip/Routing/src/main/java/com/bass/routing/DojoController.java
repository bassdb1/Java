package com.bass.routing;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class DojoController {
	
	// Using 'PathVariable annotation
    @RequestMapping("/{wordInput}")
    public String showLocation(@PathVariable("wordInput") String wordInput ) {
    	if(wordInput.equals("dojo")) {
    		return "The dojo is awesome!";
    	}else if (wordInput.equals("burbank-dojo")) {
    		return "Burbank Dojo is located in Southern California";

    	}else if (wordInput.equals("san-jose")) {
    		return "SJ dojo is the headquarters";
    	}else {
    		return "Sorry the dojo you are looking for is not here";
    	}
    	
    }

}
