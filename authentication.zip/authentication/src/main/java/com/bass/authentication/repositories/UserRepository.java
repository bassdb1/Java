package com.bass.authentication.repositories;

import org.springframework.data.repository.CrudRepository;

import com.bass.authentication.models.User;

// In the <> put in the Model name this 'Repository' is  Interfacing, 'User' Model, data type of PK = Long
// PK = Primary Key

public interface UserRepository extends CrudRepository<User, Long> {
	 User findByEmail(String email);

}
