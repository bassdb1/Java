public class PythagoreanTest {
    public static void main(String[] args){
        Pythagorean result = new Pythagorean();  // New Instance of Pythagorean
        double output = result.calculateHypotenuse(3, 4);
        System.out.println(output);

    }
    
}
