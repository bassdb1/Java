// *** Repsitory ***


package com.bass.mvc.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.bass.mvc.models.Book;


// *** Book Repository Interface ****

// Need an @Repository Annotation

@Repository
// <Book> is our 'Book' Model and the 'primary key 'ID' in (Book.java) 'data type is 'long'

// CRUD allows us to 'Create' 'Read', 'Update', 'Delete'
public interface BookRepository extends CrudRepository<Book, Long> {
	
	// this method retrieves all the books from the database
	List<Book> findAll();
    
    // this method finds books with descriptions containing the search stringcopy
    List<Book> findByDescriptionContaining(String search);
    
    // this method counts how many titles contain a certain string
    Long countByTitleContaining(String search);
    
    // this method deletes a book that starts with a specific title
    Long deleteByTitleStartingWith(String search);

}
