//*** Services ***



package com.bass.mvc.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.bass.mvc.models.Book;
import com.bass.mvc.repositories.BookRepository;

// Service Annotation
@Service
public class BookService {
	
// need to 'inject' our book repository
	
	// the 'bookRepository' variable will call all the 'Methods' we have in 
	// ..  the 'BookRepository' Interface, like 'findAll()', etc
	private final BookRepository bookRepository;
	
	// dependency injection
	
	public BookService(BookRepository bookRepository) {
		this.bookRepository = bookRepository;
		
	}
	
	
	// In our service, we created 3 methods. 
	
	// 1.  One to retrieve all the books.  
	
	// 2.  One to create a specific book.
	
	// 3.  One to retrieve a specific book.
	
	   // returns all the books
    public List<Book> allBooks() {
        return bookRepository.findAll();
    }
    // creates a book
    public Book createBook(Book b) {
        return bookRepository.save(b);
    }
    // retrieves a book
    // .. OPtional means it will return a book or not. 
    public Book findBook(Long id) {
        Optional<Book> optionalBook = bookRepository.findById(id);
        if(optionalBook.isPresent()) {
            return optionalBook.get();
        } else {
            return null;
        }
	
    }
    
    // Update a Book
    
    public Book updateBook(Long id, String title, String description, String language, Integer numberOfPages) {
        Book toUpdate = bookRepository.findById(id).orElse(null);
        if(toUpdate == null) {
        	return null;
        	
        }else {
        	toUpdate.setTitle(title);
        	toUpdate.setDescription(description);
        	toUpdate.setLanguage(language);
        	toUpdate.setNumberOfPages(numberOfPages);
        	
        	return bookRepository.save(toUpdate);
        	
        }
    	
    
    }
    
    
    // Delete a Book 
    
    public void deleteBook(Long id) {
    	this.bookRepository.deleteById(id);
    	
    	
    	
    }
    
    
    
}
